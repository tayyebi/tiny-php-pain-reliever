<HTML>
<HEAD>
<TITLE>فارسی نویسی در GD</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
<!--
.style1 {
	font-size: 24px;
	color: #FFFFFF;
}
.style2 {
	font-size: 18px;
	color: #FFFFFF;
}
-->
</style>
</HEAD>
<BODY >
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td bgcolor="#4B577E"><div align="center" class="style1" dir="rtl">فارسی نویسی در GD </div></td>
  </tr>
  <tr>
 <td bgcolor="#858EB6" dir="rtl" align="right"><div align="center"><FORM action="example.php" method="POST" >
<CENTER><IMG src="test01.php?text=<?php echo $_POST['text']; ?>" border="1" />
<INPUT type="text" name="text" size="50" dir="rtl" value="<?php echo $_POST['text']; ?>"><br>
<INPUT type="submit" value="آزمایش کنید">
</FORM>
</div>
</td>
  </tr>
</table>

</BODY>