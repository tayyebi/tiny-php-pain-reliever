select * from
Posts
where Id like @id