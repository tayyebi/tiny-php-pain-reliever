</div>
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- jQuery Plugin -->
    <script src="static/js/jquery.slim.js"></script>

    <!-- Bootstrap Core JS -->
    <script src="static/js/bootstrap.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace();
      $('#basicExampleModal.show').modal('show');
    </script>

  </body>
</html>