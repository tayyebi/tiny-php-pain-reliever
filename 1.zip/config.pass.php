<?php

$_SERVER['PHP_AUTH_USER'] = "root";
$_SERVER['PHP_AUTH_PW'] = "123";

?>